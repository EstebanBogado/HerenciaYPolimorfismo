package ar.edu.unlam.pb2;

public class Tomate extends Cultivo {

}
