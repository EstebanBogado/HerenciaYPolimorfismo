package ar.edu.unlam.pb2;

public abstract class Cultivo {
	//cantidadDeRegadosNecesarios (clase)
	//cantidadDiasNecesarios
	//vecesQueSeRego (instancia)

	
}
